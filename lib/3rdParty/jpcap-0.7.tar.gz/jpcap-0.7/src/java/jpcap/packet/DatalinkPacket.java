package jpcap.packet;

/** This class represents datalink layer packet. */
public abstract class DatalinkPacket implements java.io.Serializable
{
}
